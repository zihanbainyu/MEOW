# Bayes Factor
A Matlab package for Bayes Factor statistical analysis (`+bf`). 

Source coude is available at:
https://github.com/klabhub/bayesFactor

For documentation and examples, see:
https://klabhub.github.io/bayesFactor/

## Dependencies
Mathworks Statistics and Machine Learning Toolbox.
Known to work with: Matlab R2017a or later.
Known not to work with: Matlab R2016b or earlier.

## Issues
For bug reports, code issues, or feature request, please submit a new Issue on GitHub: https://github.com/klabhub/bayesFactor/issues

## Contact Info
Bart Krekelberg - bart@vision.rutgers.edu

To cite, please use
[![DOI](https://zenodo.org/badge/162604707.svg)](https://zenodo.org/badge/latestdoi/162604707)

## Notes
Earlier versions of this toolbox also contained code to simplify working with (generalized) linear mixed models in Matlab (+lm). Those tools
have been moved to the kStats toolbox (https://github.com/klabhub/kStats).
